--
-- PostgreSQL database dump
--

-- Dumped from database version 12.2
-- Dumped by pg_dump version 12.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: book; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.book (
    id integer NOT NULL,
    name character(155) NOT NULL,
    articul character(55) NOT NULL,
    date date NOT NULL,
    autor character(155) NOT NULL,
    status integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.book OWNER TO root;

--
-- Name: book_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.book_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.book_id_seq OWNER TO root;

--
-- Name: book_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.book_id_seq OWNED BY public.book.id;


--
-- Name: client; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.client (
    id integer NOT NULL,
    fio character(155) NOT NULL,
    passport character(25) NOT NULL
);


ALTER TABLE public.client OWNER TO root;

--
-- Name: client_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.client_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.client_id_seq OWNER TO root;

--
-- Name: client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.client_id_seq OWNED BY public.client.id;


--
-- Name: employee; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.employee (
    id integer NOT NULL,
    fio character(155) NOT NULL,
    "position" character(55) NOT NULL
);


ALTER TABLE public.employee OWNER TO root;

--
-- Name: employee_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.employee_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employee_id_seq OWNER TO root;

--
-- Name: employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.employee_id_seq OWNED BY public.employee.id;


--
-- Name: issue; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.issue (
    id integer NOT NULL,
    date1 date,
    date2 date,
    book_id integer NOT NULL,
    client_id integer NOT NULL,
    employee_id integer NOT NULL,
    condition character(55),
    date3 date,
    return_id integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.issue OWNER TO root;

--
-- Name: issue_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.issue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.issue_id_seq OWNER TO root;

--
-- Name: issue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.issue_id_seq OWNED BY public.issue.id;


--
-- Name: book id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.book ALTER COLUMN id SET DEFAULT nextval('public.book_id_seq'::regclass);


--
-- Name: client id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.client ALTER COLUMN id SET DEFAULT nextval('public.client_id_seq'::regclass);


--
-- Name: employee id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.employee ALTER COLUMN id SET DEFAULT nextval('public.employee_id_seq'::regclass);


--
-- Name: issue id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.issue ALTER COLUMN id SET DEFAULT nextval('public.issue_id_seq'::regclass);


--
-- Data for Name: book; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.book (id, name, articul, date, autor, status) FROM stdin;
2	Алые паруса                                                                                                                                                	ап-1                                                   	2021-05-04	Александр Грин                                                                                                                                             	0
3	Евгений Онегин                                                                                                                                             	ео-21                                                  	2021-05-04	Александр Пушкин                                                                                                                                           	0
5	Анна Каренина                                                                                                                                              	ак-456                                                 	2021-05-04	Лев Толстой                                                                                                                                                	0
4	Мастер и Маргарита                                                                                                                                         	мм-33                                                  	2021-05-04	Михаил Булгаков                                                                                                                                            	1
1	Война и Мир                                                                                                                                                	лт-123                                                 	2021-05-28	Лев Толстой                                                                                                                                                	0
\.


--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.client (id, fio, passport) FROM stdin;
1	Петров Петр Сергеевич                                                                                                                                      	39 14 778899             
2	Лебедев Александр Александрович                                                                                                                            	14 39 557711             
\.


--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.employee (id, fio, "position") FROM stdin;
1	Иванов Иван Алексеевич                                                                                                                                     	инженер                                                
2	Кудрявцев Александр Абакарович                                                                                                                             	писатель                                               
\.


--
-- Data for Name: issue; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.issue (id, date1, date2, book_id, client_id, employee_id, condition, date3, return_id) FROM stdin;
14	2021-05-03	2021-05-03	1	1	1	\N	\N	0
15	2021-05-04	2021-05-04	4	1	1	\N	\N	0
17	2021-05-03	2021-05-20	1	1	2	нориальное                                             	2021-05-04	7
7	2021-05-03	2021-05-20	1	1	1	\N	\N	7
\.


--
-- Name: book_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.book_id_seq', 5, true);


--
-- Name: client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.client_id_seq', 2, true);


--
-- Name: employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.employee_id_seq', 2, true);


--
-- Name: issue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.issue_id_seq', 17, true);


--
-- Name: book book_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.book
    ADD CONSTRAINT book_pkey PRIMARY KEY (id);


--
-- Name: client client_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_pkey PRIMARY KEY (id);


--
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (id);


--
-- Name: issue issue_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.issue
    ADD CONSTRAINT issue_pkey PRIMARY KEY (id);


--
-- Name: issue book; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.issue
    ADD CONSTRAINT book FOREIGN KEY (book_id) REFERENCES public.book(id);


--
-- Name: issue client; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.issue
    ADD CONSTRAINT client FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: issue employee; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.issue
    ADD CONSTRAINT employee FOREIGN KEY (employee_id) REFERENCES public.employee(id);


--
-- PostgreSQL database dump complete
--

